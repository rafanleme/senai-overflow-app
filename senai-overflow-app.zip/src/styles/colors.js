
const colors = {
  dark: "#282a36",
  darkGray: "#44475a",
  darkTransparent: "#282a36CC",
  light: "#EDF2F4",
  lightTransparent: "#EDF2F455",
  primary: "#EF233C",
  secondary: "#D90429",
}

export default colors;